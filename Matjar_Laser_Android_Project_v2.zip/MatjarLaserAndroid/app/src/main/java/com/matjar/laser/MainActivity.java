package com.matjar.laser;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.content.SharedPreferences;
import java.io.BufferedReader;
import java.io.InputStreamReader;

public class MainActivity extends Activity {
    private final int bg = Color.rgb(13, 16, 28);
    private final int panel = Color.rgb(25, 30, 48);
    private final int red = Color.rgb(255, 55, 85);
    private final int blue = Color.rgb(44, 130, 255);
    private SharedPreferences prefs;
    private TextView scanResult;
    private SeekBar sensitivity;
    private static final int PICK_FILE = 101;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("laser_settings", MODE_PRIVATE);
        showHome();
    }

    private GradientDrawable rounded(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(radius);
        return d;
    }

    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setGravity(Gravity.CENTER_VERTICAL);
        return t;
    }

    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(22, 18, 22, 22);
        l.setBackgroundColor(bg);
        return l;
    }

    private void addCard(LinearLayout root, View child) {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setPadding(16, 14, 16, 14);
        wrap.setBackground(rounded(panel, 24));
        wrap.addView(child);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, 10, 0, 10);
        root.addView(wrap, p);
    }

    private Button button(String label, int color) {
        Button b = new Button(this);
        b.setText(label); b.setTextColor(Color.WHITE);
        b.setAllCaps(false); b.setTextSize(15);
        b.setBackground(rounded(color, 18));
        return b;
    }

    private void showHome() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = column();
        scroll.addView(root);

        TextView brand = text("متجر ليزر", 30, Color.WHITE, true);
        root.addView(brand);
        TextView subtitle = text("أدوات وإعدادات للاعبين", 15, Color.LTGRAY, false);
        root.addView(subtitle);

        TextView hero = text("مرحباً بك 👋\\nإدارة إعداداتك في مكان واحد", 21, Color.WHITE, true);
        hero.setPadding(18, 18, 18, 18);
        hero.setBackground(rounded(red, 24));
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, -2);
        hp.setMargins(0, 18, 0, 12);
        root.addView(hero, hp);

        LinearLayout scanBox = new LinearLayout(this);
        scanBox.setOrientation(LinearLayout.VERTICAL);
        scanBox.addView(text("فحص ملف", 19, Color.WHITE, true));
        TextView info = text("اختر ملفاً من جهازك لعرض معلوماته الأساسية. لا يغيّر التطبيق ملفات اللعبة.", 14, Color.LTGRAY, false);
        info.setPadding(0, 8, 0, 12);
        scanBox.addView(info);
        Button choose = button("اختيار ملف للفحص", blue);
        scanBox.addView(choose);
        scanResult = text("لم يتم اختيار ملف بعد.", 14, Color.LTGRAY, false);
        scanResult.setPadding(0, 12, 0, 0);
        scanBox.addView(scanResult);
        choose.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.setType("*/*");
            i.addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(i, PICK_FILE);
        });
        addCard(root, scanBox);

        LinearLayout settingsBox = new LinearLayout(this);
        settingsBox.setOrientation(LinearLayout.VERTICAL);
        settingsBox.addView(text("إعدادات الحساسية", 19, Color.WHITE, true));
        int saved = prefs.getInt("sensitivity", 60);
        TextView val = text("قيمة تجريبية: " + saved + " / 100", 15, Color.LTGRAY, false);
        settingsBox.addView(val);
        sensitivity = new SeekBar(this);
        sensitivity.setMax(100);
        sensitivity.setProgress(saved);
        settingsBox.addView(sensitivity);
        sensitivity.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean user) { val.setText("قيمة تجريبية: " + p + " / 100"); }
            public void onStartTrackingTouch(SeekBar s) {}
            public void onStopTrackingTouch(SeekBar s) { prefs.edit().putInt("sensitivity", s.getProgress()).apply(); }
        });
        TextView note = text("هذه قيمة محفوظة داخل التطبيق فقط، ولا تغيّر إعدادات اللعبة تلقائياً.", 13, Color.LTGRAY, false);
        note.setPadding(0, 8, 0, 0);
        settingsBox.addView(note);
        addCard(root, settingsBox);

        Button reset = button("استعادة القيمة الافتراضية", red);
        reset.setOnClickListener(v -> {
            prefs.edit().putInt("sensitivity", 60).apply();
            sensitivity.setProgress(60);
        });
        root.addView(reset);

        TextView foot = text("الإصدار 1.0 · متجر ليزر", 12, Color.GRAY, false);
        foot.setGravity(Gravity.CENTER);
        foot.setPadding(0, 22, 0, 8);
        root.addView(foot);

        setContentView(scroll);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_FILE && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            if (uri != null) {
                String name = uri.getLastPathSegment();
                scanResult.setText("تم اختيار الملف:\\n" + name + "\\nتم استلام الملف للفحص الأساسي. لا يتم تعديل الملف.");
                Toast.makeText(this, "تم اختيار الملف", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
